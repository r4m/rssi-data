//*****************************
//**  Author: Massimo Marra
//**  University of Padova
//*****************************

*File data_testX.mat contains all the data about the TEST number X.
The columns are:

 - [ID] identification number of the fixed sensor

 - [RSS(dBm)] received signal strength

 - [RSSI(dBm)] received signal strength indicator
 
 - [LQI(dBm)] link quality indicator

 - [Ch] transmission channel

 - [Power] transmission power

 - [Counter] packet counter

 - [Time(s)] packet timestamp

 - [x_ID] x-coordinate of the fixed node with id=[ID]
 
 - [y_ID] y-coordinate of the fixed node with id=[ID]	

 - [x_count] x-coordinate of the mobile node in the [Counter]-th position of the path

 - [y_count] y-coordinate of the mobile node in the [Counter]-th position of the path


*The "data_testX.xls" EXCEL file contains the same data of file data_testX.mat	

*The "data_testX.csv" file contains the same data of file data_testX.mat in a CSV (comma-separated values) format

*Files dati_radio_testX.xls and nodo_counter_testX.csv contain values needed by the MATLAB scripts. The former represents all the data collected during the test, the latter contains a mapping beetween [Counter] value and mobile node position.

*File nodo_counter_testX.xls contains in another format the data of files nodo_counter_testX.csv.

*File Percorso_testX.jpg is an immage of the TestX path. 
