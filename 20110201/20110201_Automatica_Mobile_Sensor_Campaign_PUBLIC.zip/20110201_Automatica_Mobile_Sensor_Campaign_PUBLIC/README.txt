/*
 * Copyright (c) 2011, Department of Information Engineering, University of Padova.
 * All rights reserved.
 *
 * ===================================================================================

Each directory contains files of a TEST performed to collect RSSI and LQI data.

The TESTs are made on the South-West plan of the Department of 
Information Engineering of the University of Padova.

The data had been acquired with Ehud. Ehud is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation,either version 3 of the License, or (at your option) any later version.
Ehud can be found at http://sourceforge.net/projects/ehud/.


Filippo Zanella

filippo.zanella[AT]dei.unipd.it
